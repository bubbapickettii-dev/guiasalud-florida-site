// Public funnel handler: serves the pre-rendered pages + tracking endpoints. Ported 1:1 from the Flask app (app.py):
// /go/<code> redirects, /c/<slug>, /qa, /api/event, /api/route-preview, no-buyer mode (no contact info is collected).
import type { D1Database } from "@cloudflare/workers-types";
import { PAGES } from "./pages.generated";
import { DATA } from "./data.generated";

type Env = { DB?: D1Database };
type Row = Record<string, any>;

const BOT_UA = /bot|crawl|spider|preview|facebookexternalhit|slack|whatsapp|telegram|curl|wget|python-requests|headless/i;
const LINKS = DATA.LINKS as unknown as Record<string, Row>;
const CAMPAIGNS = DATA.CAMPAIGNS as unknown as Record<string, Row>;
const CAMP_BY_ID = DATA.CAMPAIGN_BY_ID as unknown as Record<string, Row>;
const ANGLES = DATA.ANGLES as unknown as Record<string, string>;
const EXPS = DATA.PAGE_EXPERIMENTS as unknown as string[][];
const MESES = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"];
const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

function html(body: string, status = 200, cache = "public, max-age=300"): Response {
  return new Response(body, { status, headers: { "content-type": "text/html; charset=utf-8", "cache-control": cache } });
}
function json(o: unknown, status = 200): Response {
  return new Response(JSON.stringify(o), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });
}
function redirect(loc: string): Response {
  return new Response(null, { status: 302, headers: { location: loc, "cache-control": "no-store" } });
}
function cookie(req: Request, name: string): string {
  const m = (req.headers.get("cookie") || "").match(new RegExp("(?:^|;\\s*)" + name + "=([^;]*)"));
  return m ? m[1] : "";
}
function qs(o: Map<string, string>): string {
  const u = new URLSearchParams();
  o.forEach((v, k) => u.append(k, v));
  return u.toString();
}
const now = () => new Date().toISOString().slice(0, 19).replace("T", " ");
const s = (v: unknown, n: number): string | null => (typeof v === "string" && v ? v.slice(0, n) : null);

function pageExperiment(entry: string | null): string | null {
  if (!entry) return null;
  for (const [pat, id] of EXPS) if (entry === pat || (pat.endsWith("*") && entry.startsWith(pat.slice(0, -1)))) return id;
  return null;
}

function etToday(override?: string | null): { y: number; m: number; d: number; iso: string; ms: number } {
  let iso = override && /^\d{4}-\d{2}-\d{2}$/.test(override) ? override : new Date().toLocaleDateString("en-CA", { timeZone: "America/New_York" });
  const [y, m, d] = iso.split("-").map(Number);
  return { y, m, d, iso, ms: Date.UTC(y, m - 1, d) };
}
const dayMs = (iso: string) => { const [y, m, d] = iso.split("-").map(Number); return Date.UTC(y, m - 1, d); };

function oep(path: string, url: URL): Response {
  const es = path.startsWith("/inscripcion");
  const t = etToday(url.searchParams.get("test") === "1" ? url.searchParams.get("today") : null);
  const F = DATA.FACTS;
  let st = "over", days = 0;
  if (t.ms < dayMs(F.oep_start)) { st = "pre"; days = Math.round((dayMs(F.oep_start) - t.ms) / 864e5); }
  else if (t.ms <= dayMs(F.dec15)) { st = "open"; days = Math.round((dayMs(F.dec15) - t.ms) / 864e5); }
  else if (t.ms <= dayMs(F.oep_end)) { st = "grace"; days = Math.round((dayMs(F.oep_end) - t.ms) / 864e5); }
  const pretty = es ? `${t.d} de ${MESES[t.m - 1]} de ${t.y}` : `${MONTHS[t.m - 1]} ${t.d}, ${t.y}`;
  const body = (PAGES[`${path}|${st}`] || "").replaceAll("__PRETTY__", pretty).replaceAll("__ISO__", t.iso).replaceAll("__DAYS__", String(days));
  return html(body, 200, "public, max-age=600");
}

async function go(req: Request, env: Env, code: string, url: URL): Promise<Response> {
  const l = LINKS[code];
  if (!l) return notFound();
  const ua = req.headers.get("user-agent") || "";
  const qa = url.searchParams.get("test") === "1" || cookie(req, "le_qa") === "1";
  if (!qa && !BOT_UA.test(ua) && env.DB) {
    try { await env.DB.prepare("INSERT INTO clicks (ts, code, campaign, utm_source, utm_content) VALUES (?,?,?,?,?)").bind(now(), code, l.campaign || null, l.utm_source || null, l.utm_content || null).run(); } catch (_e) { /* never block the redirect */ }
  }
  const q = new Map<string, string>();
  for (const k of ["utm_source", "utm_medium", "utm_campaign", "utm_content"]) if (l[k]) q.set(k, l[k]);
  q.set("lc", code);
  if (l.experiment_id) q.set("x", l.experiment_id);
  if (l.partner_id) q.set("partner", l.partner_id);
  if (l.phone_variant) q.set("pv", l.phone_variant);
  if (url.searchParams.get("test") === "1") q.set("test", "1");
  const c = url.searchParams.get("c") || "";
  if (/^[a-z0-9_-]{1,40}$/.test(c)) q.set("utm_content", c);
  const aq = url.searchParams.get("a") || "";
  const angleOverride = aq in ANGLES ? aq : null;
  const camp = CAMP_BY_ID[l.campaign];
  const lp = String(l.landing_page || "").trim();
  if (lp.startsWith("/") && !lp.startsWith("//")) {
    const i = lp.indexOf("?");
    const path = i < 0 ? lp : lp.slice(0, i);
    const merged = new Map<string, string>();
    if (i >= 0) new URLSearchParams(lp.slice(i + 1)).forEach((v, k) => merged.set(k, v));
    q.forEach((v, k) => merged.set(k, v));
    if (path === "/check" && (angleOverride || (!merged.has("a") && l.angle))) merged.set("a", angleOverride || l.angle);
    return redirect(path + "?" + qs(merged));
  }
  q.set("a", angleOverride || l.angle || ((l.lang === "es" || (camp && camp.lang === "es")) ? "es_check" : "health_check"));
  return redirect("/check?" + qs(q));
}

async function apiEvent(req: Request, env: Env, url: URL): Promise<Response> {
  let d: Row = {};
  try { const t = await req.text(); d = JSON.parse(t.slice(0, 20000)) || {}; } catch (_e) { d = {}; }
  if (!env.DB) return json({ ok: false }, 503);
  if (!d.experiment_id && d.entry_page) d.experiment_id = pageExperiment(String(d.entry_page));
  const vid = String(d.visitor_id || "").slice(0, 64) || crypto.randomUUID().replace(/-/g, "");
  const t = (d.is_test || url.searchParams.get("test") === "1" || cookie(req, "le_qa") === "1") ? 1 : 0;
  const ev = String(d.event || "").slice(0, 40);
  if (/\/\/[^/]+\/(admin|agent|partner|qa)(\/|\?|$)/.test(String(d.page_url || ""))) return json({ ok: true, ignored: "internal page" });
  let data: Row = {};
  if (d.data && typeof d.data === "object") {
    for (const [k, v] of Object.entries(d.data as Row)) {
      if (/phone|email|tel|mail/i.test(k)) continue;
      data[k] = typeof v === "string" ? v.replace(/\d{7,}/g, "[redacted]").slice(0, 300) : v;
    }
  }
  const step = String(d.step || "").replace(/\d{7,}/g, "[redacted]").slice(0, 120) || null;
  const pv = typeof d.phone_variant === "string" && /^[A-Z]$/.test(d.phone_variant) ? d.phone_variant : null;
  const entry = s(d.entry_page, 120);
  const ts = now();
  const db = env.DB;
  const stmts = [
    db.prepare("INSERT OR IGNORE INTO visitors (visitor_id, first_seen, last_seen, first_campaign, first_utm_source, first_utm_medium, first_utm_campaign, first_utm_content, first_link_code, partner_id, referrer, landing_url, stage, is_test, experiment_id, angle, lang, phone_variant, entry_page) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
      .bind(vid, ts, ts, s(d.campaign, 80), s(d.utm_source, 80), s(d.utm_medium, 80), s(d.utm_campaign, 80), s(d.utm_content, 80), s(d.link_code, 40), s(d.partner_id, 40), s(d.referrer, 300), s(d.page_url, 500), "VISITOR", t, s(d.experiment_id, 40), s(d.angle, 40), s(d.lang, 8), pv, entry),
  ];
  if (["tool_start", "tool_complete", "step", "form_start"].includes(ev)) stmts.push(db.prepare("UPDATE visitors SET stage='RESPONDER' WHERE visitor_id=? AND stage='VISITOR'").bind(vid));
  stmts.push(db.prepare("UPDATE visitors SET last_seen=? WHERE visitor_id=?").bind(ts, vid));
  stmts.push(db.prepare("INSERT INTO events (ts, visitor_id, session_id, campaign, event, step, utm_source, utm_medium, utm_campaign, utm_content, link_code, partner_id, page_url, data, is_test, variant, experiment_id, angle, lang, phone_variant, entry_page) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
    .bind(ts, vid, s(d.session_id, 64), s(d.campaign, 80), ev, step, s(d.utm_source, 80), s(d.utm_medium, 80), s(d.utm_campaign, 80), s(d.utm_content, 80), s(d.link_code, 40), s(d.partner_id, 40), s(d.page_url, 500), JSON.stringify(data).slice(0, 2000), t, s(d.variant, 40), s(d.experiment_id, 40), s(d.angle, 40), s(d.lang, 8), pv, entry));
  try { await db.batch(stmts); } catch (_e) { return json({ ok: false }, 500); }
  return json({ ok: true, visitor_id: vid });
}

async function form(req: Request): Promise<URLSearchParams> {
  try { return new URLSearchParams((await req.text()).slice(0, 6000)); } catch (_e) { return new URLSearchParams(); }
}

function notFound(): Response { return html(PAGES["404"] || "Not found", 404, "no-store"); }

export async function handleSite(req: Request, env: Env): Promise<Response | null> {
  const url = new URL(req.url);
  let p = url.pathname;
  if (p.length > 1 && p.endsWith("/")) p = p.slice(0, -1);
  if (p.startsWith("/_") || p.startsWith("/assets/") || p === "/api/user") return null; // platform internals
  const m = req.method;
  const isGet = m === "GET" || m === "HEAD";

  if (isGet) {
    if (p === "/healthz") {
      let db = "none";
      try { if (env.DB) { await env.DB.prepare("SELECT 1").first(); db = "ok"; } } catch (_e) { db = "error"; }
      return json({ ok: true, db });
    }
    if (p === "/robots.txt") {
      const body = DATA.INDEX ? "User-agent: *\nAllow: /\nDisallow: /api\n" + `Sitemap: ${DATA.BASE}/sitemap.xml\n` : "User-agent: *\nDisallow: /\n";
      return new Response(body, { headers: { "content-type": "text/plain; charset=utf-8", "cache-control": "public, max-age=300" } });
    }
    if (p === "/sitemap.xml") {
      const day = etToday().iso;
      const xml = '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' + DATA.SITEMAP.map((u) => `<url><loc>${DATA.BASE}${u}</loc><lastmod>${day}</lastmod></url>`).join("") + "</urlset>";
      return new Response(xml, { headers: { "content-type": "application/xml; charset=utf-8", "cache-control": "public, max-age=3600" } });
    }
    if (p.startsWith("/go/")) return go(req, env, p.slice(4), url);
    if (p.startsWith("/c/")) {
      const c = CAMPAIGNS[p.slice(3)];
      if (!c) return notFound();
      const q = new Map<string, string>();
      url.searchParams.forEach((v, k) => q.set(k, v));
      if (!q.has("a")) q.set("a", c.lang === "es" ? "es_check" : "health_check");
      return redirect("/check?" + qs(q));
    }
    if (p === "/qa") {
      const on = (url.searchParams.get("on") ?? "1") === "1";
      const r = html(PAGES[on ? "/qa|on" : "/qa|off"] || "ok", 200, "no-store");
      r.headers.append("set-cookie", on ? "le_qa=1; Path=/; Max-Age=31536000; SameSite=Lax; Secure" : "le_qa=; Path=/; Max-Age=0; SameSite=Lax; Secure");
      return r;
    }
    if (p === "/despidos") return redirect("/aprende/me-despidieron-seguro-medico-florida");
    if (p === "/api/route-preview") {
      const c = CAMP_BY_ID[url.searchParams.get("campaign") || ""];
      if (!c) return json({ error: "not_found" }, 404);
      return json({ available: false, consent_email_only: (DATA.EMAIL_ONLY as any)[c.lang === "es" ? "es" : "en"] });
    }
    if (p === "/open-enrollment-2027" || p === "/inscripcion-abierta-2027") return oep(p, url);
    if (p === "/check") {
      let a = url.searchParams.get("a") || (url.searchParams.get("lang") === "es" ? "es_check" : "health_check");
      if (!(a in ANGLES)) a = "health_check";
      const pg = PAGES[`/check|${a}`];
      return pg ? html(pg) : notFound();
    }
    const hit = PAGES[p];
    if (hit && p !== "404") return html(hit);
    return notFound();
  }

  if (m === "POST") {
    if (p === "/api/event") return apiEvent(req, env, url);
    if (p === "/api/phone-check") return json({ valid: false, reason: "unavailable" });
    if (p === "/api/lead") return json({ ok: false, error: "not_accepting_submissions" }, 503); // no-buyer mode: nothing is collected
    if (p === "/optout") {
      const f = await form(req);
      if (env.DB) {
        for (const kind of ["email", "phone"]) {
          let v = (f.get(kind) || "").trim().toLowerCase();
          if (kind === "phone") { const dg = v.replace(/\D/g, ""); v = dg.length === 10 ? dg : ""; }
          if (v) { try { await env.DB.prepare("INSERT OR REPLACE INTO optouts (key, kind, ts, source) VALUES (?,?,?,?)").bind(v.slice(0, 120), kind, now(), "web_form").run(); } catch (_e) { /* ignore */ } }
        }
      }
      return html(PAGES["/optout|done"] || "Done", 200, "no-store");
    }
    if (p === "/contact") {
      const f = await form(req);
      const msg = (f.get("message") || "").trim().slice(0, 2000);
      if (msg && !(f.get("website") || "").trim() && env.DB) {
        try { await env.DB.prepare("INSERT INTO contact_msgs (ts, message, reply_to) VALUES (?,?,?)").bind(now(), msg, (f.get("reply_to") || "").trim().slice(0, 120)).run(); } catch (_e) { /* ignore */ }
      }
      return html(PAGES["/contact|done"] || "Thank you", 200, "no-store");
    }
  }
  return notFound();
}

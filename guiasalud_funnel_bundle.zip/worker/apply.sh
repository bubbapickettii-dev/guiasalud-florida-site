#!/bin/bash
# Run inside the website checkout (repo root). Usage: bash apply.sh <unzipped_dir>
set -e
SRC="$1"; APP=app
mkdir -p $APP/src/site $APP/public/static
cp "$SRC/worker/handler.ts" "$SRC/worker/pages.generated.ts" "$SRC/worker/data.generated.ts" $APP/src/site/
cp "$SRC/worker/server.ts" $APP/src/server.ts
cp "$SRC/worker/0002_funnel.sql" $APP/migrations/0002_funnel.sql
cp "$SRC/public/static/"* $APP/public/static/
cat > $APP/app.manifest.json <<'J'
{
  "db": true,
  "r2": false,
  "kv": false,
  "durableObject": null
}
J

-- Funnel tracking tables (additive only). Mirrors the Flask app schema. No contact data is stored by the funnel itself.
CREATE TABLE IF NOT EXISTS visitors (
  visitor_id TEXT PRIMARY KEY, first_seen TEXT, last_seen TEXT, first_campaign TEXT, first_utm_source TEXT, first_utm_medium TEXT,
  first_utm_campaign TEXT, first_utm_content TEXT, first_link_code TEXT, partner_id TEXT, referrer TEXT, landing_url TEXT,
  stage TEXT DEFAULT 'VISITOR', is_test INTEGER DEFAULT 0, experiment_id TEXT, angle TEXT, lang TEXT, phone_variant TEXT, entry_page TEXT
);
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, visitor_id TEXT, session_id TEXT, campaign TEXT, event TEXT, step TEXT,
  utm_source TEXT, utm_medium TEXT, utm_campaign TEXT, utm_content TEXT, link_code TEXT, partner_id TEXT, page_url TEXT, data TEXT,
  is_test INTEGER DEFAULT 0, variant TEXT, experiment_id TEXT, angle TEXT, lang TEXT, phone_variant TEXT, entry_page TEXT
);
CREATE INDEX IF NOT EXISTS ix_ev_v ON events(visitor_id);
CREATE INDEX IF NOT EXISTS ix_ev_e ON events(event, is_test);
CREATE TABLE IF NOT EXISTS clicks (id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, code TEXT, campaign TEXT, utm_source TEXT, utm_content TEXT);
CREATE TABLE IF NOT EXISTS contact_msgs (id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, message TEXT, reply_to TEXT);
CREATE TABLE IF NOT EXISTS optouts (key TEXT PRIMARY KEY, kind TEXT, ts TEXT, source TEXT);
